package com.example.android.chatactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.support.design.widget.FloatingActionButton;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ChatActivity extends AppCompatActivity {
    private static final DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    private static final String url = "http://ec2-52-24-61-118.us-west-2.compute.amazonaws.com/chat/";

    TextView messageText;
    TextView messageUser;
    TextView messageTime;
    ListView listOfMessages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        displayChatMessages();
        setContentView(R.layout.activity_chat);

        FloatingActionButton fab = (FloatingActionButton)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText input = (EditText)findViewById(R.id.input);

                RequestQueue queue = Volley.newRequestQueue(getApplication());

                String inputText = input.getText().toString();

                String currentUser = "";
                Bundle account = getIntent().getExtras();
                if (account != null) {
                    currentUser = account.getCharSequence("email").toString();
                }
                final ChatMessage message = new ChatMessage(inputText, "sokola@purdue.edu");

                JSONObject JSONChatMessage = new JSONObject();
                try {
                    JSONChatMessage.put("user1@purdue_edu", inputText);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                final JSONObject messagesObj = new JSONObject();

                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url + "sokola@purdue.edu", null, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            response.accumulate("user1@purdue_edu", parseChatMessage(message));
                            JSONArray newArray = response.getJSONArray("user1@purdue_edu");
                            JSONObject currObject = new JSONObject();
                            currObject.put("user1@purdue_edu", newArray);
                            message.putChat("sokola@purdue.edu", "user1@purdue_edu", currObject, getApplication());
                            JSONObject otherObject = new JSONObject();
                            otherObject.put("sokola@purdue_edu", newArray);
                            message.putChat("user1@purdue.edu", "sokola@purdue_edu", otherObject, getApplication());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });

                queue.add(jsonObjectRequest);
                input.setText("");
            }
        });
    }

    private void displayChatMessages() {
        listOfMessages = (ListView)findViewById(R.id.list_of_messages);
        messageText = (TextView)findViewById(R.id.messageTextView);
        messageUser = (TextView)findViewById(R.id.message_user);
        messageTime = (TextView)findViewById(R.id.message_time);

        if (messageText == null) {
            System.out.println("messageText is null");
        }

        //This is where I pull the text from the database I think
        //parseDBChatMessage(message);
        RequestQueue queue = Volley.newRequestQueue(getApplication());
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url + "sokola@purdue.edu", null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray messages = response.getJSONArray("user1@purdue_edu");
                    System.out.println(messages.getString(0));
                    messageText.setText(messages.getString(0));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        //messageUser.setText("user1@purdue_edu");
        queue.add(jsonObjectRequest);
        Calendar cal = Calendar.getInstance();
        //messageTime.setText(dateFormat.format(cal.getTime()));
    }

    private String parseChatMessage(ChatMessage message) {
        //format chat message as a string: time + userid + message
        return (message.getMessageTime() + message.getMessageUser() + ".." + message.getMessageText());
    }

    private ChatMessage parseDBChatMessage(String message) {
        ChatMessage newMessage;
        String messageUser = "";
        String messageText = "";

        int i = 17;
        //if we find "..", we know its the end of the email address
        for (; i < message.length(); i++) {
            if (message.substring(i, i+1) == "..") {
                break;
            }
            messageUser += message.charAt(i);
        }

        for (; i < message.length(); i++) {
            messageText += message.charAt(i);
        }

        newMessage = new ChatMessage(messageText, messageUser);

        return newMessage;
    }
}
